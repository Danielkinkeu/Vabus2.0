import React from "react";

import Header from "../../components/header/header";

import ComponentAgence from "../../components/component agence/componentagence";
const PageAgence = () => {
  return (
    <div>
      <Header />

      <ComponentAgence />
    </div>
  );
};
export default PageAgence;
