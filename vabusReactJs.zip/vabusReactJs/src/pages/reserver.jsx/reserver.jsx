import React from "react";

import Reserver from "../../components/reserver/reserver";
const PageReserver = () => {
  return (
    <div>
      <Reserver />
    </div>
  );
};
export default PageReserver;
