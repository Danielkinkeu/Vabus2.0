import React from "react";

import Connexion from "../../components/connexion/connexion";
const PageConnexion = () => {
  return (
    <div>
      <Connexion />
    </div>
  );
};
export default PageConnexion;
