import React from "react";

import Inscription from "../../components/inscription/inscription";
const PageInscription = () => {
  return (
    <div>
      <Inscription />
    </div>
  );
};
export default PageInscription;
